
  # Dating App Design

  This is a code bundle for Dating App Design. The original project is available at https://www.figma.com/design/PlucoeZyg878XSJc7IAnZH/Dating-App-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  